AnonBoard - demo anonymous imageboard (no word filtering)

Startup:
1. npm install
2. export IP_SALT="a-long-random-secret"
   export MOD_KEY="a-different-secret"
3. npm start
Open http://localhost:3000

Notes:
- This demo intentionally does NOT filter words. Users can post any text.
- We escape HTML on render to prevent XSS. Do NOT disable escaping.
- You must comply with local laws. Do not use this to host illegal material.
