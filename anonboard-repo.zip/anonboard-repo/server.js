// server.js - Minimal anonymous board with no word filters
const express = require('express');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const Database = require('better-sqlite3');
const crypto = require('crypto');
const helmet = require('helmet');
const { RateLimiterMemory } = require('rate-limiter-flexible');
const xssFilters = require('xss-filters');

const app = express();
const db = new Database('./data.db');

// --- CONFIG ---
const UPLOAD_DIR = path.join(__dirname, 'uploads');
const PORT = process.env.PORT || 3000;
const IP_SALT = process.env.IP_SALT || 'CHANGE_THIS_TO_A_RANDOM_SECRET';
const MOD_KEY = process.env.MOD_KEY || 'changeme-mod-key';

// create upload dir
if (!fs.existsSync(UPLOAD_DIR)) fs.mkdirSync(UPLOAD_DIR);

// multer for file uploads (images + text files), limited size
const upload = multer({
  dest: UPLOAD_DIR,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter: (req, file, cb) => {
    const allowed = ['image/png','image/jpeg','image/gif','image/webp','text/plain'];
    cb(null, allowed.includes(file.mimetype));
  }
});

// rate limiter: 5 posts per minute per IP
const rateLimiter = new RateLimiterMemory({
  points: 5,
  duration: 60
});

// security headers
app.use(helmet());
app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.use('/uploads', express.static(UPLOAD_DIR));
app.use(express.static('public'));

// --- DB INIT ---
db.exec(`
CREATE TABLE IF NOT EXISTS boards (id INTEGER PRIMARY KEY, name TEXT UNIQUE);
CREATE TABLE IF NOT EXISTS threads (id INTEGER PRIMARY KEY, board_id INTEGER, content TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, ip_hash TEXT, file TEXT);
CREATE TABLE IF NOT EXISTS replies (id INTEGER PRIMARY KEY, thread_id INTEGER, content TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, ip_hash TEXT, file TEXT);
CREATE TABLE IF NOT EXISTS reports (id INTEGER PRIMARY KEY, target_kind TEXT, target_id INTEGER, reason TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP, ip_hash TEXT);
`);

// helper: deterministic hash for IP + salt (so you can link posts by same IP but not reveal raw IP)
function hashIP(ip){
  return crypto.createHmac('sha256', IP_SALT).update(String(ip)).digest('hex');
}

// basic helper to escape HTML on render (we store raw text, but escape when serving HTML)
function escapeHTML(str){
  return xssFilters.inHTMLData(str || '');
}

// --- Routes ---
// list boards
app.get('/api/boards', (req,res) => {
  const rows = db.prepare('SELECT id, name FROM boards ORDER BY name').all();
  res.json(rows);
});

// create board
app.post('/api/boards', (req,res) => {
  const name = (req.body.name || '').trim();
  if (!name) return res.status(400).json({ error: 'bad name' });
  db.prepare('INSERT OR IGNORE INTO boards (name) VALUES (?)').run(name);
  res.json({ ok: true });
});

// create thread (anonymous, no word filtering)
app.post('/api/boards/:board/threads', upload.single('file'), async (req,res) => {
  try {
    await rateLimiter.consume(req.ip);
  } catch (e) {
    return res.status(429).json({ error: 'too many requests' });
  }
  const board = req.params.board;
  const boardRow = db.prepare('SELECT id FROM boards WHERE name = ?').get(board);
  if (!boardRow) return res.status(404).json({ error: 'board not found' });

  // We accept any words. We do NOT allow raw HTML to be interpreted later by escaping on render.
  const raw = req.body.content || '';
  const ip_hash = hashIP(req.ip || 'unknown');

  let filePath = null;
  if (req.file) filePath = '/uploads/' + path.basename(req.file.path);

  const stmt = db.prepare('INSERT INTO threads (board_id, content, ip_hash, file) VALUES (?, ?, ?, ?)');
  const info = stmt.run(boardRow.id, raw, ip_hash, filePath);

  res.json({ ok: true, threadId: info.lastInsertRowid });
});

// post a reply
app.post('/api/threads/:id/replies', upload.single('file'), async (req,res) => {
  try {
    await rateLimiter.consume(req.ip);
  } catch (e) {
    return res.status(429).json({ error: 'too many requests' });
  }
  const threadId = Number(req.params.id);
  const thread = db.prepare('SELECT id FROM threads WHERE id = ?').get(threadId);
  if (!thread) return res.status(404).json({ error: 'thread not found' });

  const raw = req.body.content || '';
  const ip_hash = hashIP(req.ip || 'unknown');

  let filePath = null;
  if (req.file) filePath = '/uploads/' + path.basename(req.file.path);

  db.prepare('INSERT INTO replies (thread_id, content, ip_hash, file) VALUES (?, ?, ?, ?)').run(threadId, raw, ip_hash, filePath);
  res.json({ ok: true });
});

// get threads (JSON)
app.get('/api/boards/:board/threads', (req,res) => {
  const board = req.params.board;
  const boardRow = db.prepare('SELECT id FROM boards WHERE name = ?').get(board);
  if (!boardRow) return res.status(404).json({ error: 'board not found' });

  const threads = db.prepare('SELECT id, content, created_at, file FROM threads WHERE board_id = ? ORDER BY created_at DESC LIMIT 50').all(boardRow.id);
  // escape content for safety in API consumer that might render it without escaping
  const escaped = threads.map(t => ({ ...t, content: escapeHTML(t.content) }));
  res.json(escaped);
});

// get single thread + replies
app.get('/api/threads/:id', (req,res) => {
  const id = Number(req.params.id);
  const thread = db.prepare('SELECT id, content, created_at, file FROM threads WHERE id = ?').get(id);
  if (!thread) return res.status(404).json({ error: 'not found' });
  const replies = db.prepare('SELECT id, content, created_at, file FROM replies WHERE thread_id = ? ORDER BY created_at ASC').all(id);
  res.json({
    thread: { ...thread, content: escapeHTML(thread.content) },
    replies: replies.map(r => ({ ...r, content: escapeHTML(r.content) }))
  });
});

// report content (for moderators)
app.post('/api/report', (req,res) => {
  const { target_kind, target_id, reason } = req.body;
  const ip_hash = hashIP(req.ip || 'unknown');
  db.prepare('INSERT INTO reports (target_kind, target_id, reason, ip_hash) VALUES (?, ?, ?, ?)').run(target_kind, target_id, reason || '', ip_hash);
  res.json({ ok: true });
});

// moderator endpoints - simple key check (replace with real auth in production)
function requireMod(req, res, next){
  const key = req.headers['x-moderator-key'] || '';
  if (key !== MOD_KEY) return res.status(403).json({ error: 'forbidden' });
  next();
}

app.post('/mod/delete', requireMod, (req,res) => {
  const { kind, id } = req.body;
  if (kind === 'thread') db.prepare('DELETE FROM threads WHERE id = ?').run(id);
  if (kind === 'reply') db.prepare('DELETE FROM replies WHERE id = ?').run(id);
  res.json({ ok: true });
});

app.get('/mod/reports', requireMod, (req,res) => {
  const rows = db.prepare('SELECT * FROM reports ORDER BY created_at DESC LIMIT 200').all();
  res.json(rows);
});

// simple index page (will be replaced by public/index.html in real usage)
app.get('/', (req,res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => console.log('Anon board listening on', PORT));
